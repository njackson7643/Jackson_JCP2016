import os
import sys
from sys import argv
import numpy as np

scripts, nstart, nstop, EBeta = argv

work_path = '/home/nej544/Percolation_rewrite/Paper_Fig1/'
fold_path = '25latt_1D_EBeta'+EBeta+'_KMC'
fold_name = 'batch_'

start = int(nstart)
stop = int(nstop)
sample_num = int(stop-start)

#print sample_num

os.chdir(work_path+fold_path)
array = np.zeros( (sample_num) , dtype = float)
OParray = np.zeros( (sample_num) , dtype = float)
Eavg_array = np.zeros( (sample_num), dtype = float)
Evar_array = np.zeros( (sample_num), dtype = float)
Havg_array = np.zeros( (sample_num), dtype = float)
Hvar_array = np.zeros( (sample_num), dtype = float)
#for name,s in zip(folders,range(len(folders))):
for s in range(start+1,stop+1):
    os.chdir("batch_"+str(s))
    txtfile = [k for k in os.listdir('.') if '.log' in k][0]
    f = open(txtfile,'r')
    flines = f.readlines()
    for line in flines:
        templine = line.split()
        if len(templine) > 0 and templine[0] == "mean":
            array[s-start-1] = float(templine[1])
    f.close()
    os.chdir('..')

#print OParray
print str(round(np.mean(array),3))+' +/- '+str(round(np.std(array),3))
