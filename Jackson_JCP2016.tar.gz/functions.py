from numpy import *
from math import *
from random import *
from sets import Set
import matplotlib
matplotlib.use('Agg')
from pylab import *
from matplotlib.ticker import AutoMinorLocator
from scipy.interpolate import spline
from collections import OrderedDict
from mpl_toolkits.mplot3d import axes3d
import time

#Rotate a given vector by an angle theta around the x-axis.
def rotate_x(theta,vector):
    rx = zeros((3,3) , float)
    rx[0,0] = 1
    rx[0,1] = 0
    rx[0,2] = 0
    rx[1,0] = 0
    rx[1,1] = cos(theta)
    rx[1,2] = -sin(theta)
    rx[2,0] = 0
    rx[2,1] = sin(theta)
    rx[2,2] = cos(theta)
    return dot(rx,vector)

#Rotate a given vector by an angle theta around the y-axis
def rotate_y(theta,vector):
    ry = zeros((3,3) , float)
    ry[0,0] = cos(theta)
    ry[0,1] = 0
    ry[0,2] = sin(theta)
    ry[1,0] = 0
    ry[1,1] = 1
    ry[1,2] = 0
    ry[2,0] = -sin(theta)
    ry[2,1] = 0
    ry[2,2] = cos(theta)
    return dot(ry,vector)

#Rotate a given vector by an angle theta around the z-axis
def rotate_z(theta,vector):
    rz = zeros((3,3) , float)
    rz[0,0] = cos(theta)
    rz[0,1] = -sin(theta)
    rz[0,2] = 0
    rz[1,0] = sin(theta)
    rz[1,1] = cos(theta)
    rz[1,2] = 0
    rz[2,0] = 0
    rz[2,1] = 0
    rz[2,2] = 1
    return dot(rz,vector)

#Perform a random rotation in x,y,z on a given vector init, and return the new vector vec
def rand_vect_move(init,rand_x,rand_y,rand_z):
    vec = rotate_z(rand_z,rotate_y(rand_y,rotate_x(rand_x,init)))
    return vec

#Make a lattice of a particular type.  3 choices (crystalline: 0,totally random: 1)
def make_lattice(dim,lat_type):
    #Make crystalline lattice
    lattice = zeros((dim,dim,dim) , dtype = list)
    if lat_type == '0':
        for i in range(dim):
            for j in range(dim):
                for k in range(dim):
                    lattice[i,j,k] = [rand_vect_move([1,0,0],0.,0.,0.),rand_vect_move([0,1,0],0.,0.,0.),rand_vect_move([0,0,1],0.,0.,0.)]
        return lattice
    #Make totally random lattice
    elif lat_type == '1':
        for i in range(dim):
            for j in range(dim):
                for k in range(dim):
                    rx = random()*(2.*math.pi)
                    ry = random()*(2.*math.pi)
                    rz = random()*(2.*math.pi)
                    lattice[i,j,k] = [rand_vect_move([1,0,0],rx,ry,rz),rand_vect_move([0,1,0],rx,ry,rz),rand_vect_move([0,0,1],rx,ry,rz)]
        return lattice
    else:
        print "You have entered an invalid lattice type\n"
        

#Compute the interaction energy between two lattice sites.
#vec1,vec3,vec5 correspond to vectors on molecule 1, and vec2,vec4,vec6 correspond to vectors on molecule 2
#transvect is the lattice vector defining the translation direction between the two sites
def get_energy(vec1,vec2,vec3,vec4,vec5,vec6,transvect,v1Escale,v2Escale,v3Escale):
    dot1 = dot(v1Escale*vec1,transvect)
    dot2 = dot(v1Escale*vec2,transvect)
    dot3 = dot(v2Escale*vec3,transvect)
    dot4 = dot(v2Escale*vec4,transvect)
    dot5 = dot(v3Escale*vec5,transvect)
    dot6 = dot(v3Escale*vec6,transvect)
    return (((dot1*dot2)**2)+((dot1*dot4)**2)+((dot1*dot6)**2)+((dot3*dot2)**2)+((dot3*dot4)**2)+((dot3*dot6)**2)+((dot5*dot2)**2)+((dot5*dot4)**2)+((dot5*dot6)**2))

#Compute the coupling between two lattice sites.  Convections are the same as in get_energy.
def get_coupling(vec1,vec2,vec3,vec4,vec5,vec6,transvect,v1Hscale,v2Hscale,v3Hscale):
    dot1 = dot(v1Hscale*vec1,transvect)
    dot2 = dot(v1Hscale*vec2,transvect)
    dot3 = dot(v2Hscale*vec3,transvect)
    dot4 = dot(v2Hscale*vec4,transvect)
    dot5 = dot(v3Hscale*vec5,transvect)
    dot6 = dot(v3Hscale*vec6,transvect)
    #print dot1,dot2,dot3,dot4,dot5,dot6
    return (((dot1*dot2)**2)+((dot1*dot4)**2)+((dot1*dot6)**2)+((dot3*dot2)**2)+((dot3*dot4)**2)+((dot3*dot6)**2)+((dot5*dot2)**2)+((dot5*dot4)**2)+((dot5*dot6)**2))

#Compute the total energy of the entire lattice
#Takes as arguments an array of all lattice sites in the system and their corresponding interactions vectors
#lat size is the dimension of the lattice
#Eint is the interaction strength that is multiplied through all vectors.  It is some multiple of kT
def get_tot_energy(array,lat_size,Eint,v1Escale,v2Escale,v3Escale):
    tot_E = 0.
    for i in range(lat_size):
        if i == lat_size-1:
            iup = 0
            idown = i-1
        elif i == 0:
            iup = i+1
            idown = lat_size-1
        else:
            iup = i+1
            idown = i-1
        for j in range(lat_size):
            if j == lat_size-1:
                jup = 0
                jdown = j-1
            elif j == 0:
                jup = j+1
                jdown = lat_size-1
            else:
                jup = j+1
                jdown = j-1
            for k in range(lat_size):
                if k == lat_size-1:
                    kup = 0
                    kdown = k-1
                elif k == 0:
                    kup = k+1
                    kdown = lat_size-1
                else:
                    kup = k+1
                    kdown = k-1
                tot_E += Eint*get_energy(array[i,j,k][0],array[idown,j,k][0],array[i,j,k][1],array[idown,j,k][1],array[i,j,k][2],array[idown,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
                tot_E += Eint*get_energy(array[i,j,k][0],array[iup,j,k][0],array[i,j,k][1],array[iup,j,k][1],array[i,j,k][2],array[iup,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
                tot_E += Eint*get_energy(array[i,j,k][0],array[i,jdown,k][0],array[i,j,k][1],array[i,jdown,k][1],array[i,j,k][2],array[i,jdown,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
                tot_E += Eint*get_energy(array[i,j,k][0],array[i,jup,k][0],array[i,j,k][1],array[i,jup,k][1],array[i,j,k][2],array[i,jup,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
                tot_E += Eint*get_energy(array[i,j,k][0],array[i,j,kdown][0],array[i,j,k][1],array[i,j,kdown][1],array[i,j,k][2],array[i,j,kdown][2],[0,0,1],v1Escale,v2Escale,v3Escale)
                tot_E += Eint*get_energy(array[i,j,k][0],array[i,j,kup][0],array[i,j,k][1],array[i,j,kup][1],array[i,j,k][2],array[i,j,kup][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    return tot_E

#Perform a single Monte Carlo rotational move on a single lattice site.
#Function picks a random site on which to perform this move.                
#A Metropolis Monte Carlo algorithm is used to compare the energy post flip to the energy pre flip, and accept or reject that move.
#Beta is inverse annealing temperature
def one_MC_move(array,beta,Eint,lat_size,v1Escale,v2Escale,v3Escale):
    i = randint(0,lat_size)
    j = randint(0,lat_size)
    k = randint(0,lat_size)
    rx = random()*2.*math.pi
    ry = random()*2.*math.pi
    rz = random()*2.*math.pi
    if i == lat_size-1:
        iup = 0
        idown = i-1
    elif i == 0:
        iup = i+1
        idown = lat_size-1
    else:
        iup = i+1
        idown = i-1
    if j == lat_size-1:
        jup = 0
        jdown = j-1
    elif j == 0:
        jup = j+1
        jdown = lat_size-1
    else:
        jup = j+1
        jdown = j-1
    if k == lat_size-1:
        kup = 0
        kdown = k-1
    elif k == 0:
        kup = k+1
        kdown = lat_size-1
    else:
        kup = k+1
        kdown = k-1
    pre_E = 0
    pre_E += Eint*get_energy(array[i,j,k][0],array[idown,j,k][0],array[i,j,k][1],array[idown,j,k][1],array[i,j,k][2],array[idown,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[iup,j,k][0],array[i,j,k][1],array[iup,j,k][1],array[i,j,k][2],array[iup,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,jdown,k][0],array[i,j,k][1],array[i,jdown,k][1],array[i,j,k][2],array[i,jdown,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,jup,k][0],array[i,j,k][1],array[i,jup,k][1],array[i,j,k][2],array[i,jup,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,j,kdown][0],array[i,j,k][1],array[i,j,kdown][1],array[i,j,k][2],array[i,j,kdown][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,j,kup][0],array[i,j,k][1],array[i,j,kup][1],array[i,j,k][2],array[i,j,kup][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    post_E = 0
    newvect0 = rand_vect_move(array[i,j,k][0],rx,ry,rz)
    newvect1 = rand_vect_move(array[i,j,k][1],rx,ry,rz)
    newvect2 = rand_vect_move(array[i,j,k][2],rx,ry,rz)
    post_E += Eint*get_energy(newvect0,array[idown,j,k][0],newvect1,array[idown,j,k][1],newvect2,array[idown,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[iup,j,k][0],newvect1,array[iup,j,k][1],newvect2,array[iup,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,jdown,k][0],newvect1,array[i,jdown,k][1],newvect2,array[i,jdown,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,jup,k][0],newvect1,array[i,jup,k][1],newvect2,array[i,jup,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,j,kdown][0],newvect1,array[i,j,kdown][1],newvect2,array[i,j,kdown][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,j,kup][0],newvect1,array[i,j,kup][1],newvect2,array[i,j,kup][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    if post_E < pre_E:
        array[i,j,k] = [newvect0,newvect1,newvect2]
    else:
        criteria = math.exp(-beta*(post_E-pre_E))
        random_check = random()
        if random_check < criteria:
            array[i,j,k] = [newvect0,newvect1,newvect2]
    return array

def one_nonlocal_MC_move(array,beta,Eint,lat_size,v1Escale,v2Escale,v3Escale):
    i = randint(0,lat_size)
    j = randint(0,lat_size)
    k = randint(0,lat_size)
    rx = random()*2*math.pi
    ry = random()*2*math.pi
    rz = random()*2*math.pi
    if i == lat_size-1:
        iup = 1
        idown = i-2
    elif i == lat_size-2:
        iup = 0
        idown = i-2
    elif i == 0:
        iup = i+2
        idown = lat_size-2
    elif i == 1:
        iup = i+2
        idown = lat_size-1
    else:
        iup = i+2
        idown = i-2
    if j == lat_size-1:
        jup = 1
        jdown = j-2
    elif j == lat_size-2:
        jup = 0
        jdown = j-2
    elif j == 0:
        jup = j+2
        jdown = lat_size-2
    elif j == 1:
        jup = j+2
        jdown = lat_size-1
    else:
        jup = j+2
        jdown = j-2
    if k == lat_size-1:
        kup = 1
        kdown = k-2
    elif k == lat_size-2:
        kup = 0
        kdown = k-2
    elif k == 0:
        kup = k+2
        kdown = lat_size-2
    elif k == 1:
        kup = k+2
        kdown = lat_size-1
    else:
        kup = k+2
        kdown = k-2
    pre_E = 0
    pre_E += Eint*get_energy(array[i,j,k][0],array[idown,j,k][0],array[i,j,k][1],array[idown,j,k][1],array[i,j,k][2],array[idown,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[iup,j,k][0],array[i,j,k][1],array[iup,j,k][1],array[i,j,k][2],array[iup,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,jdown,k][0],array[i,j,k][1],array[i,jdown,k][1],array[i,j,k][2],array[i,jdown,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,jup,k][0],array[i,j,k][1],array[i,jup,k][1],array[i,j,k][2],array[i,jup,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,j,kdown][0],array[i,j,k][1],array[i,j,kdown][1],array[i,j,k][2],array[i,j,kdown][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    pre_E += Eint*get_energy(array[i,j,k][0],array[i,j,kup][0],array[i,j,k][1],array[i,j,kup][1],array[i,j,k][2],array[i,j,kup][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    post_E = 0
    newvect0 = rand_vect_move(array[i,j,k][0],rx,ry,rz)
    newvect1 = rand_vect_move(array[i,j,k][1],rx,ry,rz)
    newvect2 = rand_vect_move(array[i,j,k][2],rx,ry,rz)
    post_E += Eint*get_energy(newvect0,array[idown,j,k][0],newvect1,array[idown,j,k][1],newvect2,array[idown,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[iup,j,k][0],newvect1,array[iup,j,k][1],newvect2,array[iup,j,k][2],[1,0,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,jdown,k][0],newvect1,array[i,jdown,k][1],newvect2,array[i,jdown,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,jup,k][0],newvect1,array[i,jup,k][1],newvect2,array[i,jup,k][2],[0,1,0],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,j,kdown][0],newvect1,array[i,j,kdown][1],newvect2,array[i,j,kdown][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    post_E += Eint*get_energy(newvect0,array[i,j,kup][0],newvect1,array[i,j,kup][1],newvect2,array[i,j,kup][2],[0,0,1],v1Escale,v2Escale,v3Escale)
    if post_E < pre_E:
        array[i,j,k] = [newvect0,newvect1,newvect2]
    else:
        criteria = math.exp(-beta*(post_E-pre_E))
        random_check = random()
        if random_check < criteria:
            array[i,j,k] = [newvect0,newvect1,newvect2]
    return array



#Perform a certain number of MC steps at a given temperature beta
def run_MC_moves(array,nsteps,beta_start,beta_end,lat_size,Eint,v1Escale,v2Escale,v3Escale,anneal_step_size):
    if lat_size == 1:
        return array
    else:
        curr_array = array
        print 'Performing Monte Carlo Lattice Annealing...'
        beta = beta_start
        counter = 0
        anneal_array = np.arange(beta_start,beta_end+anneal_step_size,anneal_step_size)
        for step in anneal_array:
            beta = float(step)
            print "Annealing for "+str(nsteps)+" steps at Eint*Beta = "+str(beta)
            print 'Energy at MC Step 0 is '+str(round(get_tot_energy(curr_array,lat_size,Eint,v1Escale,v2Escale,v3Escale),2))+' a.u.'
            for n in range(nsteps):
                if n%10000 == 0:
                    print 'Energy at MC Step ' +str(n+nsteps*counter)+' is '+str(round(get_tot_energy(curr_array,lat_size,Eint,v1Escale,v2Escale,v3Escale),2))+' a.u.'
                output = one_MC_move(curr_array,beta,Eint,lat_size,v1Escale,v2Escale,v3Escale)
                curr_array = output
#                if n%1000000000 == 0 and n < 3000000:
#                    output = one_nonlocal_MC_move(curr_array,beta,Eint,lat_size,v1Escale,v2Escale,v3Escale)
#                    curr_array = output
            counter += 1
        #plot_lattice_3D(curr_array,lat_size)
        print 'Monte Carlo Lattice Annealing Complete!\n'
        print 'Computing Lattice Properties from final orientation...\n'
        return curr_array

#Returns the difference of two lists
def setdiff(list1,list2):
    s = set(list2)
    list3 = [x for x in list1 if x not in s]
    return list3

#Function to compute Miller-Abrahams style rate
#DON'T USE THIS NEEDS IF STATEMENT
def GoldenRule(Hab,Temp,deltaG):
    kET = ((2*math.pi)/(6.626*10**-34))*(abs(Hab)**2)*(1/(1.6*10**-19))
    #print kET
    return kET

#Function to compute marcus rate
def Marcus_Rate(Hab,lambdaC,Temp,deltaG):
    kET = ((2*math.pi)/(6.626*10**-34))*((Hab)**2)*(1/(math.sqrt(4*math.pi*lambdaC*(1.38*10**-23)*Temp)))*math.exp(-(((lambdaC+deltaG)**2)/(4*lambdaC*(1.38*10**-23)*Temp)))
    #print kET
    return kET

#Function to compute the Jortner rate.  Approximate values for parameters taken from Liu, T.; Troisi, A. "Absolute Rate of Charge Separation and Recombination in a Molecular Model of the P3HT/PCBM Interface", JPCC, 2011.
def Jortner_Rate(Hab,Temp,deltaG):
    weff = 0.18*1.6*10**-19
    Seff = 1.4
    lam_ext = 0.05*1.6*10**-19
    planck = 6.626*10**-34
    pi = 3.14159
    kB = 1.38*10**-23
    prefactor = (2.*pi/planck)*(Hab**2.)*(1./(4.*pi*lam_ext*kB*Temp))**0.5
#    print prefactor
    FCsum = 0.
    for v in range(10):
        FCsum += math.exp(-Seff)*(((Seff)**v)/math.factorial(v))*math.exp(-((lam_ext+v*weff+deltaG)**2)/(4*lam_ext*kB*Temp))
    return prefactor*FCsum

##################
#The following functions are all involved in computing the Landau de Gennes order parameter for the lattice and its sites
##################

#Compute the Landau de Gennes Q tensor for every vector at every lattice site, and store for future use
def Q_per_site(array,lat_size):
    accum_array = zeros( (lat_size,lat_size,lat_size,3,3) , dtype = float)
    if lat_size == 1:
        accum_array[0,0,0] = abs(np.multiply.outer(array[0][0][1],array[0][0][1]))
        return accum_array
    else:
        for i in range(len(array)):
            for j in range(len(array)):
                for k in range(len(array)):
                    accum_array[i,j,k] = abs(np.multiply.outer(array[i,j,k][1],array[i,j,k][1]))
        return accum_array

def compute_Q_fast(array,istart,jstart,kstart,lat_size):
    e1_array = []
    e2_array = []
    e3_array = []
    Qtens_bond = zeros( (3,3) , float)
    Qtens_save = zeros( (3,3) , float)
    inner_block = []
    outer_block = []
    #use str(int(1+(int(lat_size-1)/2)))
    #shorten the range to 2 to just compute nearest neighbors for local energy calcs
    for n in range(0,2):
        if n == 0:
            e1_array.append([0,-0.5])
            e2_array.append([0,-0.5])
            e3_array.append([0,1])
        elif n > 0:
            #print n
            for i in range(istart-n,istart+n+1):
                if i > lat_size-1:
                    iuse = i-lat_size
                elif i < 0:
                    iuse = i+lat_size
                else:
                    iuse = i
                for j in range(jstart-n,jstart+n+1):
                    if j > lat_size-1:
                        juse = j-lat_size
                    elif j < 0:
                        juse = j+lat_size
                    else:
                        juse = j
                    for k in range(kstart-n,kstart+n+1):
                        if k > lat_size-1:
                            kuse = k-lat_size
                        elif k < 0:
                            kuse = k+lat_size
                        else:
                            kuse = k
                        outer_block.append((iuse,juse,kuse))
            calc_shell = setdiff(outer_block,inner_block)
            inner_block = outer_block
            outer_block = []
            sorted_calc = sorted(calc_shell)
            new_shell = zeros( (3,3),float)
            Qtens_bond = Qtens_save
            for m in range(len(sorted_calc)):
                iel = sorted_calc[m][0]
                jel = sorted_calc[m][1]
                kel = sorted_calc[m][2]
                new_shell += array[iel,jel,kel]
            Qtens_bond += new_shell
            Qtens_save = Qtens_bond
            Qtens_bond = (1.5/(((2.*n)+1.)**3.))*Qtens_bond
            Qtens_bond[0,0] -= 0.5
            Qtens_bond[1,1] -= 0.5
            Qtens_bond[2,2] -= 0.5
            solution = linalg.eig(Qtens_bond)
            eigenval = real(solution[0])
            eigenvect = real(solution[1])
            idx = eigenval.argsort()
            eigenval = eigenval[idx]
            e1_array.append([n,round(eigenval[0],3)])
            e2_array.append([n,round(eigenval[1],3)])
            e3_array.append([n,round(eigenval[2],3)])
    return e1_array,e2_array,e3_array
            
#Partition a vector of length n into a vector of length n/m with elements of length m
def chunks(l,n):
    if n < 1:
        n = 1
    return [l[i:i + n] for i in range(0,len(l),n)]

#Function to set up site energies.  I have chosen an uncorrelated Gaussian distribution of site energies
def make_siteE(lat_size,Edisorder,curr_latt):
    #print lat_size,Edisorder
    #choose '0' for uncorrelated disorder and '1' for correlated disorder
    disord_type = '0'
    eng_list = []    
    if disord_type == '0':
        print 'Site energies style: normal around 0.0 eV with width '+str(Edisorder)+' eV'
    #print energy_latt
        ord_list = []
        accum_array = Q_per_site(curr_latt,lat_size)
        energy_latt = zeros( (lat_size,lat_size,lat_size) , float)
        for a in range(0,lat_size):
            for b in range(0,lat_size):
                for c in range(0,lat_size):
                    output = compute_Q_fast(accum_array,a,b,c,lat_size)
                    #print output
                    outpute1 = output[2]
                    outpute2 = output[1]
                    outpute3 = output[0]
                    #print outpute1
                    site_eng = 1.6*(10**-19)*gauss(0.,Edisorder)
                    energy_latt[a,b,c] = site_eng
                    eng_list.append(site_eng)
                    ord_list.append(outpute1[1][1])
        #print energy_latt
        return energy_latt,eng_list,ord_list
    elif disord_type == '1':
        print 'Site energies style: Landau/De Gennes/normal around 0.0 eV with width '+str(Edisorder)+' eV'
        ord_list = []
        accum_array = Q_per_site(curr_latt,lat_size)
        energy_latt = zeros( (lat_size,lat_size,lat_size) , float)
        for a in range(0,lat_size):
            for b in range(0,lat_size):
                for c in range(0,lat_size):
                    output = compute_Q_fast(accum_array,a,b,c,lat_size)
                    #print output
                    outpute1 = output[2]
                    outpute2 = output[1]
                    outpute3 = output[0]
                    #print outpute1
                    site_eng = 1.6*(10**-19)*(3-3*outpute1[1][1])*gauss(0.,Edisorder)
                    energy_latt[a,b,c] = site_eng
                    eng_list.append(site_eng)
                    ord_list.append(outpute1[1][1])
        return energy_latt,eng_list,ord_list
    else:
        print 'You have not selected a valid disorder type!'

#Create the dictionary that contains all of the coupling information between all nearest neighbor bonds of the system
def create_Hdict(MCLattice,lat_size,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale):
    CouplingDict = {}
    for i in range(lat_size):
        for j in range(lat_size):
            for k in range(lat_size):
                for l in range(-1,2,2):
                    if i+l < 0:
                        iuse = i+l+lat_size
                    elif i+l > lat_size -1:
                        iuse = i+l-lat_size
                    else:
                        iuse = i+l
                    transvect = [1,0,0]
#                    print MCLattice[i,j,k],MCLattice[iuse,j,k]
                    CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(iuse)+'-'+str(j)+'-'+str(k)] = Habuse*(get_coupling(MCLattice[i,j,k][0],MCLattice[iuse,j,k][0],MCLattice[i,j,k][1],MCLattice[iuse,j,k][1],MCLattice[i,j,k][2],MCLattice[iuse,j,k][2],transvect,v1Hscale,v2Hscale,v3Hscale)+gauss(0.,Habfluct))
                    #print transvect
                    #print MCLattice[i,j,k],MCLattice[iuse,j,k]
                    #print CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(iuse)+'-'+str(j)+'-'+str(k)]

                    if j+l < 0:
                        juse = j+l+lat_size
                    elif j+l > lat_size -1:
                        juse = j+l-lat_size
                    else:
                        juse = j+l
                    transvect = [0,1,0]
#                    print MCLattice[i,j,k],MCLattice[i,juse,k]
                    CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(juse)+'-'+str(k)] = Habuse*(get_coupling(MCLattice[i,j,k][0],MCLattice[i,juse,k][0],MCLattice[i,j,k][1],MCLattice[i,juse,k][1],MCLattice[i,j,k][2],MCLattice[i,juse,k][2],transvect,v1Hscale,v2Hscale,v3Hscale)+gauss(0.,Habfluct))
                    #print transvect
                    #print MCLattice[i,j,k],MCLattice[i,juse,k]
                    #print CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(juse)+'-'+str(k)]
                    if k+l < 0:
                        kuse = k+l+lat_size
                    elif k+l > lat_size -1:
                        kuse = k+l-lat_size
                    else:
                        kuse = k+l
                    transvect = [0,0,1]
                    CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(j)+'-'+str(kuse)] = Habuse*(get_coupling(MCLattice[i,j,k][0],MCLattice[i,j,kuse][0],MCLattice[i,j,k][1],MCLattice[i,j,kuse][1],MCLattice[i,j,k][2],MCLattice[i,j,kuse][2],transvect,v1Hscale,v2Hscale,v3Hscale)+gauss(0.,Habfluct))
                    #print transvect
                    #print MCLattice[i,j,k],MCLattice[i,j,kuse]
                    #print CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(j)+'-'+str(kuse)]
#Make sure that all fluctuations in the couplings are symmetric (1-1-0-2-2-1 is equivalent to 2-2-1-1-1-0
    for item in CouplingDict:
        tempitem = item.split('-')
        CouplingDict[tempitem[3]+'-'+tempitem[4]+'-'+tempitem[5]+'-'+tempitem[0]+'-'+tempitem[1]+'-'+tempitem[2]] = CouplingDict[item]
    coupling_list = []
    for item in CouplingDict:
        coupling_list.append(round(abs(CouplingDict[item])/(1.6*10**-19),4))
    #print coupling_list
    #print CouplingDict
    #print MCLattice
    return CouplingDict,coupling_list

#Create a dictionary which holds the marcus transfer rates between all sites in the system
def createRateDict(CouplingDict,lat_size,lambdaCuse,Temp,energy_latt):
    ratestyle = 'goldenrule' #Can choose a rate style of 'jortner' or 'marcus' or 'goldenrule'
    print 'KMC ratestyle: '+ratestyle+'\n'
    RateDict = {}
    for i in range(lat_size):
        for j in range(lat_size):
            for k in range(lat_size):
                for l in range(-1,2,2):
                    if i+l < 0:
                        iuse = i+l+lat_size
                    elif i+l > lat_size -1:
                        iuse = i+l-lat_size
                    else:
                        iuse = i+l
                    if ratestyle == 'marcus':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(iuse)+str(j)+str(k)] = Marcus_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(iuse)+'-'+str(j)+'-'+str(k)],lambdaCuse,Temp,(energy_latt[i,j,k]-energy_latt[iuse,j,k]))
                    elif ratestyle == 'jortner':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(iuse)+str(j)+str(k)] = Jortner_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(iuse)+'-'+str(j)+'-'+str(k)],Temp,(energy_latt[i,j,k]-energy_latt[iuse,j,k]))
                    elif ratestyle == 'goldenrule':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(iuse)+str(j)+str(k)] = GoldenRule(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(iuse)+'-'+str(j)+'-'+str(k)],Temp,(energy_latt[i,j,k]-energy_latt[iuse,j,k]))
                    if j+l < 0:
                        juse = j+l+lat_size
                    elif j+l > lat_size -1:
                        juse = j+l-lat_size
                    else:
                        juse = j+l
                    if ratestyle == 'marcus':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(juse)+str(k)] = Marcus_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(juse)+'-'+str(k)],lambdaCuse,Temp,(energy_latt[i,j,k]-energy_latt[i,juse,k]))
                    elif ratestyle == 'jortner':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(juse)+str(k)] = Jortner_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(juse)+'-'+str(k)],Temp,(energy_latt[i,j,k]-energy_latt[i,juse,k]))
                    elif ratestyle == 'goldenrule':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(juse)+str(k)] = GoldenRule(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(juse)+'-'+str(k)],Temp,(energy_latt[i,j,k]-energy_latt[i,juse,k]))
                    if k+l < 0:
                        kuse = k+l+lat_size
                    elif k+l > lat_size -1:
                        kuse = k+l-lat_size
                    else:
                        kuse = k+l
                    if ratestyle == 'marcus':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(j)+str(kuse)] = Marcus_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(j)+'-'+str(kuse)],lambdaCuse,Temp,(energy_latt[i,j,k]-energy_latt[i,j,kuse]))
                    elif ratestyle == 'jortner':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(j)+str(kuse)] = Jortner_Rate(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(j)+'-'+str(kuse)],Temp,(energy_latt[i,j,k]-energy_latt[i,j,kuse]))
                    elif ratestyle == 'goldenrule':
                        RateDict[str(i)+str(j)+str(k)+'-'+str(i)+str(j)+str(kuse)] = GoldenRule(CouplingDict[str(i)+'-'+str(j)+'-'+str(k)+'-'+str(i)+'-'+str(j)+'-'+str(kuse)],Temp,(energy_latt[i,j,k]-energy_latt[i,j,kuse]))
#line below will rpint all of the rates in the system
    #print ['10^'+str(round(log10(float(i)),2)) for i in RateDict.values()]
    #print RateDict
    return RateDict

#Take a single monte carlo step from a random site
def KMC_step(RateDict,occ_site,lat_size):
    #print occ_site
    xsite = occ_site[0]
    ysite = occ_site[1]
    zsite = occ_site[2]
    loc_rate_dict = {}
    ratesum = 0.
    for i in range(-1,2,2):
        if xsite+i < 0:
            xuse = xsite+i+lat_size
        elif xsite+i > lat_size-1:
            xuse = xsite+i-lat_size
        else:
            xuse = xsite+i
        loc_rate_dict[str(xuse)+','+str(ysite)+','+str(zsite)] = RateDict[str(xsite)+str(ysite)+str(zsite)+'-'+str(xuse)+str(ysite)+str(zsite)]
    for j in range(-1,2,2):
        if ysite+j < 0:
            yuse = ysite+j+lat_size
        elif ysite+j > lat_size-1:
            yuse = ysite+j-lat_size
        else:
            yuse = ysite+j
        loc_rate_dict[str(xsite)+','+str(yuse)+','+str(zsite)] = RateDict[str(xsite)+str(ysite)+str(zsite)+'-'+str(xsite)+str(yuse)+str(zsite)]
    for k in range(-1,2,2):
        if zsite+k < 0:
            zuse = zsite+k+lat_size
        elif zsite+k > lat_size-1:
            zuse = zsite+k-lat_size
        else:
            zuse = zsite+k
        loc_rate_dict[str(xsite)+','+str(ysite)+','+str(zuse)] = RateDict[str(xsite)+str(ysite)+str(zsite)+'-'+str(xsite)+str(ysite)+str(zuse)]
    for item in loc_rate_dict:
        ratesum += loc_rate_dict[item]
    tau = -(1./ratesum)*log(random())
    prob_array = [0.,0.,0.,0.,0.,0.]
    totprob = 0.
    for item,i in zip(loc_rate_dict,range(len(loc_rate_dict))):
        totprob += (1./ratesum)*loc_rate_dict[item]
        prob_array[i] = (item,totprob)
    testnum = random()
    for i in range(len(prob_array)):
        if i == 0:
            if testnum <= prob_array[i+1][1]:
                return prob_array[i][0],tau
        else:
            if testnum > prob_array[i][1] and testnum <= prob_array[i+1][1]:
                return prob_array[i][0],tau
            else:
                continue

#Run Kinetic Monte Carlo simulation for a certain amount of time
def run_KMC(timecutoff,RateDict,lat_size,lat_spacing):
    startpt = [randint(0,lat_size-1),randint(0,lat_size-1),randint(0,lat_size-1)]
    runpt = startpt
    trackpt = [0,0,0]
    prevrunpt = startpt
    totT = 0.
    while totT < timecutoff:
        output = KMC_step(RateDict,runpt,lat_size)
        totT += output[1]
        runpt = [int(output[0].split(',')[0]),int(output[0].split(',')[1]),int(output[0].split(',')[2])]
        if prevrunpt[0] - runpt[0] == -(lat_size-1):
            trackpt[0] -= 1
        elif prevrunpt[0] - runpt[0] == (lat_size-1):
            trackpt[0] += 1
        else:
            trackpt[0] += runpt[0] - prevrunpt[0]
        if prevrunpt[1] - runpt[1] == -(lat_size-1):
            trackpt[1] -= 1
        elif prevrunpt[1] - runpt[1] == (lat_size-1):
            trackpt[1] += 1
        else:
            trackpt[1] += runpt[1] - prevrunpt[1]
        if prevrunpt[2] - runpt[2] == -(lat_size-1):
            trackpt[2] -= 1
        elif prevrunpt[2] - runpt[2] == (lat_size-1):
            trackpt[2] += 1
        else:
            trackpt[2] += runpt[2] - prevrunpt[2]
        prevrunpt = runpt
        #print runpt
    dist = round(math.sqrt((lat_spacing*trackpt[0])**2 + (lat_spacing*trackpt[1])**2 + (lat_spacing*trackpt[2])**2),2)
    return totT,trackpt,dist

def KMC_control(KMCtot_iter,timecutoff,ratedict,lat_size,lat_spacing):
    dist_array = []
    print "Beginning KMC"
    for n in range(KMCtot_iter):
        output = run_KMC(timecutoff,ratedict,lat_size,lat_spacing)
        #print output[2]
        dist_array.append(output[2])
    print "KMC Complete"
    print "mean "+str(round(mean(dist_array),2))
    print "The mean hopping distance over "+str(timecutoff/(10**-9))+ " ns is "+str(round(mean(dist_array),2)) +' +/- '+str(round(std(dist_array),2))+' lattice units averaged over '+str(KMCtot_iter)+' trials'
    return dist_array

#take a histogram from either the KMC or coupling distribution and normalize it
def norm_hist(dist_hist,bin_S):
    tot_A = 0.
    bin_size = bin_S
    #print dist_hist
    for i in range(len(dist_hist[0])):
        tot_A += dist_hist[0][i]*bin_size
    norm_dist_hist = (zeros( len(dist_hist[0]) , float),zeros( len(dist_hist[0]), float)) 
    for j in range(len(dist_hist[0])):
        norm_dist_hist[0][j] = dist_hist[0][j]*(1./tot_A)
    for k in range(len(dist_hist[0])):
        norm_dist_hist[1][k] = dist_hist[1][k]
    return norm_dist_hist

#plot distribution of KMC charge diffusion lengths
def plot_KMC_results(dist_array,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing):
    KMCHist = plt.figure()
    ax = KMCHist.add_subplot(111)
    dist_array = array(dist_array)
    max_dist = max(dist_array)
    min_dist = min(dist_array)
    bin_size = lat_spacing
    dist_hist = np.histogram(dist_array,np.arange(min_dist,max_dist,bin_size))
    norm_dist_hist = norm_hist(dist_hist,1.)
    #print norm_dist_hist
    y = array(norm_dist_hist[0])
    x = array(norm_dist_hist[1])
    #print x
    xnew = np.linspace(min(x),max(x),50)
    interp = spline(x,y,xnew,3)
    #ax.plot(x,y,'--',color='red')
    ax.plot(xnew,interp,'-',color='black',linewidth='2.5')
    ax.fill_between(xnew,interp,0,color='green')
    plt.xlabel('Distance (Ang)',{'size':'18'})
    plt.ylabel('Probability',{'size':'18'})
    plt.suptitle('Charge Diffusion Length Distribution\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+' Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,max(x)])
    plt.ylim([0,1])
    KMCHist.savefig('KMC_hist',dpi=300)
#build the complete hamiltonian for the system.  This hamiltonian will be used for the network analysis.  In principal you could also diagonalize it to get the DOS, but the matrices quickly becoming stupidly big as the lattice gets bigger.
def build_H(array,CouplingDict,lat_size):
    #print array
#    print CouplingDict
    hamiltonian = zeros((lat_size**3,lat_size**3) , float)
    entry_dict1 = {}
    entry_dict2 = {}
    counter = 0
    for i in range(lat_size):
        for j in range(lat_size):
            for k in range(lat_size):
                entry_dict1[str(i)+','+str(j)+','+str(k)] = counter
                entry_dict2[str(counter)] = str(i)+','+str(j)+','+str(k)
           #     print array[0]
                hamiltonian[counter,counter] = array[i,j,k]
                counter += 1
    for entry in CouplingDict:
        currline = entry.split('-')
        hamiltonian[entry_dict1[currline[0]+','+currline[1]+','+currline[2]],entry_dict1[currline[3]+','+currline[4]+','+currline[5]]] = CouplingDict[entry]*(1/1.6)*10**19
        #solution = linalg.eig(hamiltonian)
        #eigenval = real(solution[0])
    eig_list = []
        #for item in eigenval:
        #    eig_list.append(round(item,2))
    return eig_list,hamiltonian,entry_dict1,entry_dict2

def net_find_new(Vthresh,CouplingDict,lat_size):
    entry_dict1 = {}
    entry_dict2 = {}
    counter = 0
    #currlist stores the connectivity of all sites
    currlist = []
    for i in range(lat_size):
        for j in range(lat_size):
            for k in range(lat_size):
                entry_dict1[str(i)+','+str(j)+','+str(k)] = counter
                entry_dict2[str(counter)] = str(i)+','+str(j)+','+str(k)
                currlist.append([counter])
                counter += 1
    for entry in CouplingDict:
        #print entry,CouplingDict[entry]
        currline = entry.split('-')
        if abs(CouplingDict[entry])/(1.6*10**-19) >= Vthresh:
            currlist[entry_dict1[currline[0]+','+currline[1]+','+currline[2]]].append(entry_dict1[currline[3]+','+currline[4]+','+currline[5]])
        else:
            continue
#    curr_set = [Set(item) for item in currlist]
    poplist = []
    #start network parsing
    i = 0
    isave = 0
    verdict = False
    vertex_deg_list = []
    for item in currlist:
        vertex_deg_list.append(len(item))
    while verdict == False:
        #print len(currlist)
        poplist = []
        for k in range(i+1,len(currlist)):
            if Set(currlist[i]) & Set(currlist[k]):
                currlist[i] += setdiff(currlist[k],currlist[i])
                poplist.append(k)
            else:
                continue
        i+=1        
        poplist.reverse()
        for item in poplist:
            currlist.pop(item)
        #print tot_elements(currlist)
        if tot_elements(currlist) != lat_size**3 and i > len(currlist)-1:
            verdict = False
            i = 0
        elif i > 100000:
            verdict = True
        elif tot_elements(currlist) == lat_size**3:
            verdict = True
            tot_net = len(currlist)
            size_hist = size_dist(currlist)
#            print currlist
            percent_perc = RgR0_calc(currlist,entry_dict2,lat_size)
            print i
            return tot_net,np.mean(size_hist),np.mean(vertex_deg_list)-1,percent_perc[0],percent_perc[1]
#    return currlist,entry_dict1,entry_dict2              
                       
#find and return the intersection of two arbitrary lists
def list_intersect(b1,b2):
    list1 = b1
    list2 = b2
    list3 = [val for val in b1 if val in b2]
    if len(list3) == 0:
        return False
    elif len(list3) > 0:
        return True

#Define the network class for use later.  This is a pretty stupid use of a class, but i'm too lazy to change it.
class Network:
    'Common base class for all networks'
    NetCount = 0

    def __init__(self):
        self.size = 0
        self.sites = []
        self.sitenum = []
        Network.list = []
        Network.NetCount += 1

    def displaySize(self):
        print "Network size is %s" % self.size

    def addSite(self,newsite,newnum):
        self.sites.append(newsite)
        self.sitenum.append(newnum)
        self.size += 1

    def printSites(self):
        print "Sites in Network :" + str(self.sites)

    def returnSites(self):
        return self.sites,self.sitenum,self.size

#run all of the calculations necessary to create the object needed for the network analysis
def prep_net(array,CouplingDict,lat_size):
    #print array
    results = build_H(array,CouplingDict,lat_size)
    eig_list = results[0]
    hamilt = results[1]
    siteDict = results[3]
    #print hamilt
    #set site energies of hamiltonian to zero to simplify network analysis
    #for i in range(len(hamilt)):
    #    hamilt[i,i] = 0            
    #kgraph = abs(hamilt)
    #for j in range(len(kgraph)):
    #    kgraph[j,j] = -1.*sum(kgraph[j])
    #kgraph = -1.*kgraph
    #lap = linalg.pinv(kgraph)
    #omega = kgraph
    #for m in range(len(omega)):
    #    for n in range(len(omega)):
    #        if n != m:
    #            omega[m,n]=1./(lap[m,m]+lap[n,n]-lap[m,n]-lap[n,m])
    #        else:
    #            omega[m,n] = 0.
    #k_ind = (1./(len(omega))**2.)*sum(omega)
    #print 'The Kirchoff index is '+str(round(k_ind,5))
    return hamilt,siteDict

#compute the total number of elements in a list of nested lists
def tot_elements(list1):
    counter = 0
    for item in list1:
        counter += len(item)
    return counter

#records the sizes of all sublists in a list
def size_dist(list1):
    size_list = []
    for item in list1:
        size_list.append(len(item))
    return size_list

#Computes the percentage of sites in the system that percolate the span of the lattice
def RgR0_calc(currlist,entrydict2,lat_size):
    RgR0_list = []
#    print currlist
    num_Net = len(currlist)
#    print num_Net
    num_perc_Net = 0.
    perc_net_size = 0.
    xlist,ylist,zlist = [],[],[]
    for entry in currlist:
        xlist,ylist,zlist = [],[],[]
        net_size = len(entry)
        for site in entry:
            sitexyz = entrydict2[str(site)].split(',')
            xlist.append(sitexyz[0])
            ylist.append(sitexyz[1])
            zlist.append(sitexyz[2])
        ordx = list(OrderedDict.fromkeys(xlist))
        ordy = list(OrderedDict.fromkeys(ylist))
        ordz = list(OrderedDict.fromkeys(zlist))
        xlen = float(len(ordx))
        ylen = float(len(ordy))
        zlen = float(len(ordz))
        #print ordx,ordy,ordz
        #print xlen,ylen,zlen,lat_size        
        if xlen/lat_size >= 1. or ylen/lat_size >= 1. or zlen/lat_size >= 1.:
            num_perc_Net += 1.
            perc_net_size += net_size
    #print perc_net_size/(lat_size**3)
    return num_perc_Net/num_Net,perc_net_size/(lat_size**3)

#find all of the unique networks of a system
def net_find(currlist,hamiltonian,entrydict2,lat_size):
    start = time.clock()
    poplist = []
    i = 0
    verdict = False
    vertex_deg_list = []
    for item in currlist:
        vertex_deg_list.append(len(item))
    while verdict == False:
        poplist = []
        #print currlist
        for k in range(i+1,len(currlist)):
            if list_intersect(sorted(currlist[i],key=int),sorted(currlist[k],key=int)) == True:
                currlist[i] = currlist[i]+setdiff(currlist[k],currlist[i])
                poplist.append(k)
            else:
                continue
        poplist.reverse()
        for item in poplist:
            currlist.pop(item)
        i+=1
#        print currlist
        if tot_elements(currlist) != lat_size**3 and i > len(currlist)-1:
            verdict = False
            i = 0
        elif i > 1000000:
            verdict = True
        elif tot_elements(currlist) == lat_size**3:
            verdict = True
            tot_net = len(currlist)
            size_hist = size_dist(currlist)
            #print currlist
            percent_perc = RgR0_calc(currlist,entrydict2,lat_size)
            end = time.clock()
            print end-start
            return tot_net,np.mean(size_hist),np.mean(vertex_deg_list)-1,percent_perc[0],percent_perc[1]

#Find all sites associated with a given network
def compute_networks(hamiltonian,Vthresh,siteDict,lat_size):
    netlist = []
    #print siteDict
    for i in range(len(hamiltonian)):
        currcol = hamiltonian[i,:]
        currNet = Network()
        currNet.addSite(siteDict[str(i)],i)
        for j in range(len(currcol)):
            if abs(currcol[j]) >= Vthresh:
                currNet.addSite(siteDict[str(j)],j)
        if len(currNet.returnSites()[1]) != 0:
            netlist.append(currNet.returnSites()[1])
    #print netlist
    return net_find(netlist,hamiltonian,siteDict,lat_size)

#def compute_networks_fast(hamiltonian,Vthresh,siteDict,lat_size):
#    netlist = []
#    for i in range(len*hamiltonian

#collate all network functions and run network analysis
def run_network(hamilt,site_dict,Hab,lat_size,net_step_size,coupdict):
    print "Beginning network computation"
    net_Vt_list = []
    Avg_list = []
    vert_deg_list = []
    RgR0_list = []
    perc_perc_list = []
    #CHANGE THIS BACK TO ABS(HAB)+.001
    for el in np.arange(0.001,abs(Hab)+0.001,net_step_size):
        print "Running analysis on |Hij| = "+str(el)+' ev'
        start=time.clock()
        testout = net_find_new(el,coupdict,lat_size)
        end1=time.clock()
        print 'newfind ' + str(end1-start) + ' seconds'
#        output = compute_networks(hamilt,el,site_dict,lat_size)
#        end2=time.clock()
#        print 'oldfind ' + str((end2-end1)) + ' seconds'
        Nnet = testout[0]
        AvgN = float(testout[1])
        RgR0 = testout[3]
        perc_perc = testout[4]
        #print perc_perc
        RgR0_list.append(RgR0)
        perc_perc_list.append(perc_perc)
        vert_deg_list.append(testout[2])
        net_Vt_list.append(math.log(Nnet))
        Avg_list.append(AvgN/lat_size**3)
    print "Network computation complete"
    return vert_deg_list,net_Vt_list,Avg_list,RgR0_list,perc_perc_list

#Plot the number of networks vs the coupling threshold
def plot_Nnet_vs_Vt(net_vt_list,Hab,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size):
    Nnet_vT = plt.figure()
    plt.plot(np.arange(0.001,abs(Hab)+0.001,net_step_size),net_vt_list,'-o',linewidth=3.0)
    plt.xlabel('$V_T$ (eV)',{'size':'18'})
    plt.ylabel('Log(NNet,e)',{'size':'18'})
    plt.suptitle('NNet vs Vthresh\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+' Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,abs(Hab)])
    plt.ylim([0,10])
    Nnet_vT.savefig('Nnet_vs_Vt',dpi=300)

#Plot the Vertex Degree vs the coupling threshold
def plot_VertDeg_vs_Vt(vert_deg_list,Hab,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size):
    vertdeg = plt.figure()
    plt.plot(np.arange(0.001,abs(Hab)+0.001,net_step_size),vert_deg_list,'-o',linewidth=3.0)
    plt.xlabel('$V_T$ (eV)',{'size':'18'})
    plt.ylabel('Vertex Degree',{'size':'18'})
    plt.suptitle('Vertex Degree vs Vthresh\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+'Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,abs(Hab)])
    plt.ylim([0,6])
    plt.show
    vertdeg.savefig('Vert_deg_vs_Vt',dpi=300)

#Plot the average network size divided by the total number of sites versus the coupling threshold
def plot_netAvg_vs_Vt(Avg_list,Hab,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size):
    netAvg = plt.figure()
    plt.plot(np.arange(0.001,abs(Hab)+0.001,net_step_size),Avg_list,'-o',linewidth=3.0)
    plt.xlabel('$V_T$ (eV)',{'size':'18'})
    plt.ylabel('Average Network Size/Total number of Sites',{'size':'18'})
    plt.suptitle('Average Network Size/Total number of Sites\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+' Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,abs(Hab)])
    plt.ylim([0,1])
    netAvg.savefig('netAvg_vs_Vt',dpi=300)

#Plot the distribution of couplings in the system
def plot_coup_dist(couplingdict,coupling_list,Hab,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing):
    CoupHist = plt.figure()
    ax = CoupHist.add_subplot(111)
    coup_array = array(coupling_list)
    max_coup = max(coup_array)
    min_coup = min(coup_array)
    bin_size = 0.001
    coup_hist = np.histogram(coup_array,np.arange(min_coup,max_coup,bin_size))
#    print coup_hist
    norm_coup_hist = norm_hist(coup_hist,1.)
#    print norm_coup_hist
    y = array(norm_coup_hist[0])
    x = array(norm_coup_hist[1])
    xnew = np.linspace(min(x),max(x),50)
    interp = spline(x,y,xnew,3)
    #ax.plot(x,y,'--',color='red')
    ax.plot(xnew,interp,'--',color='black',linewidth='2.0')
    ax.fill_between(xnew,interp,0,color='red')
    plt.xlabel('Distance (Ang)',{'size':'18'})
    plt.ylabel('Probability',{'size':'18'})
    plt.suptitle('Lattice Coupling Distribution\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+' Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,abs(Hab)])
    plt.ylim([0,1])
    CoupHist.savefig('Coupling_hist',dpi=300)

#Plot the fraction of percolated sites in the system versus coupling threshold    
def plot_RgR0(RgR0_list,perc_perc_mean,perc_perc_std,Hab,lat_size,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size):
    RgR0plot = plt.figure()
    #plt.plot(np.arange(0.001,abs(Hab)+0.001,0.001),RgR0_list,'-o')
    final = open('perc_list'+str(lat_size)+'_'+str(Eint)+'_'+str(v1Hscale)+'_'+str(v2Hscale)+'_'+str(v3Hscale)+'.txt','w')
    for item,i in zip(perc_perc_mean,range(len(perc_perc_mean))):
        final.write(str(i*net_step_size+.001)+"\t"+str(item)+"\t"+str(perc_perc_std[i])+"\n")
    final.close()
    #print len(np.arange(0.001,abs(Hab)+net_step_size,net_step_size))
    #print len(perc_perc_mean)
    plt.plot(np.arange(0.001,abs(Hab)+net_step_size,net_step_size),perc_perc_mean,'-o',linewidth = 3.0)
    plt.xlabel('$V_T$ (eV)',{'size':'18'})
    plt.ylabel('Percolating Sites/Total Sites',{'size':'18'})
    plt.suptitle('Fraction of Percolated Sites in Network vs Vthresh\nLattice Size = '+str(lat_size)+" MC steps = " + str(anneal_steps)+' Escale ('+str(v1Escale)+','+str(v2Escale)+','+str(v3Escale)+') Hscale ('+str(v1Hscale)+','+str(v2Hscale)+','+str(v3Hscale)+') Eint = '+str(Eint))
    plt.xlim([0,abs(Hab)])
    plt.ylim([0,1])
    RgR0plot.savefig('Frac_perc_sites',dpi=300)

"""
def plot_lattice_3D(curr_array,lat_size):
    fig = plt.figure()
    ax = fig.gca(projection='3d')

    x, y, z = np.meshgrid(np.arange(0,lat_size,1),
                          np.arange(0,lat_size,1),
                          np.arange(0,lat_size,1))
    
    u1 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)
    v1 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)
    w1 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)
    u2 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)
    v2 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)
    w2 = np.zeros( (lat_size,lat_size,lat_size) , dtype = float)

    for i in range(lat_size):
        for j in range(lat_size):
            for k in range(lat_size):
                u1[i,j,k] = curr_array[i,j,k][0][0]
                v1[i,j,k] = curr_array[i,j,k][0][1]
                w1[i,j,k] = curr_array[i,j,k][0][2]
                u2[i,j,k] = -1.*u1[i,j,k]
                v2[i,j,k] = -1.*v1[i,j,k]
                w2[i,j,k] = -1.*w1[i,j,k]

    ax.quiver(x, y, z, u1, v1, w1, length = 0.5,color=('g'),arrow_length_ratio=0.01,alpha=0.3)
    ax.quiver(x, y, z, u2, v2, w2, length = 0.5,color=('g'),arrow_length_ratio=0.01,alpha=0.3)
    for hh in xrange(90,280,180):
        ax.view_init(elev=hh,azim=0.)
        fig.savefig('FinalLattice_tb_'+str(hh)+".png",dpi=300)
    for ii in xrange(0,370,90):
        ax.view_init(elev=0.,azim=ii)
        fig.savefig('FinalLattice_s_'+str(ii)+".png",dpi=300)
    return 0
"""
#Control function for getting data necessary to plot KMC Charge diffusion distribution, and coupling distribution
def average_KMC(nAvg,anneal_steps,KMCtot_iter,KMCtot_time,lat_size,lat_spacing,lat_type,beta_start,beta_end,v1Escale,v2Escale,v3Escale,Eint,Edisorder,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale,lambdaCuse,Temp,anneal_step_size): 
    cum_dist_array = []
    coupling_list = []
    for i in range(int(nAvg)):
        mylatt = make_lattice(lat_size,lat_type)                  
        final_latt = run_MC_moves(mylatt,anneal_steps,beta_start,beta_end,lat_size,Eint,v1Escale,v2Escale,v3Escale,anneal_step_size)
        #print "force-exiting program"
        #sys.exit()
#old line has energy_latt = make_siteE(lat_size,Edisorder)
        #new line is below
        energy_out = make_siteE(lat_size,Edisorder,final_latt)
        energy_latt = energy_out[0]
        #use energy list to get all of the statistics about the site energies of the system
        energy_list = energy_out[1]
        ord_list = energy_out[2]
        print 'Mean OP = '+str(round(mean(ord_list),3))
        print 'Site energy variance is: '+ str(round(std(energy_list)/(1.6*10**-19),2))+' eV'
        coupdict,Ncoupling_list = create_Hdict(final_latt,lat_size,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale)
        #print coupdict
        coupling_list = coupling_list + Ncoupling_list
        print 'Mean Hij is '+str(round(mean(coupling_list),4))+' eV'
        ratedict = createRateDict(coupdict,lat_size,lambdaCuse,Temp,energy_latt)
        dist_array = KMC_control(KMCtot_iter,KMCtot_time,ratedict,lat_size,lat_spacing)
        cum_dist_array = cum_dist_array + dist_array
    return cum_dist_array,coupling_list,coupdict

#Control function for getting data necessary to plot all network properties
#nAvg = number of uniquely created lattices to average over
#anneal_steps = number of MC steps to take when thermalizing the lattice

def average_netcalc(nAvg,lat_size,anneal_steps,lat_spacing,lat_type,beta_start,beta_end,v1Escale,v2Escale,v3Escale,Eint,Edisorder,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale,Hab,net_step_size,anneal_step_size):
    vert_deg_list = np.zeros( int(round(abs(Hab)/net_step_size,0)) , float)
    
    net_Vt_list = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    Avg_list = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    perc_perc_list = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    RgR0_list = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    perc_perc_totlist = []
    for i in range(int(abs(Hab)/net_step_size)):
        perc_perc_totlist.append([])
    for i in range(int(nAvg)):
#        print str(i)
        mylatt = make_lattice(lat_size,lat_type)                  
        final_latt = run_MC_moves(mylatt,anneal_steps,beta_start,beta_end,lat_size,Eint,v1Escale,v2Escale,v3Escale,anneal_step_size)
        energy_latt = make_siteE(lat_size,Edisorder,final_latt)[0]
        coupdict,Ncoupling_list = create_Hdict(final_latt,lat_size,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale)
        #print energy_latt
        hamilt,site_dict = prep_net(energy_latt,coupdict,lat_size)
        #print 'done'
        netout = run_network(hamilt,site_dict,Hab,lat_size,net_step_size,coupdict)
        vert_deg_list += array(netout[0])
        net_Vt_list += array(netout[1])
        Avg_list += array(netout[2])
        RgR0_list += array(netout[3])
        perc_perc_list += array(netout[4])
        perc_single = array(netout[4])
        for i in range(len(perc_perc_totlist)):
            perc_perc_totlist[i].append(netout[4][i])
    perc_perc_mean = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    perc_perc_std = np.zeros( int(round(abs(Hab)/net_step_size,0)), float)
    for j in range(len(perc_perc_totlist)):
        perc_perc_mean[j] = mean(perc_perc_totlist[j])
        perc_perc_std[j] = std(perc_perc_totlist[j])
#    print perc_perc_mean,perc_perc_std
    vert_deg_list = (1./nAvg)*vert_deg_list
    net_Vt_list = (1./nAvg)*net_Vt_list
    Avg_list = (1./nAvg)*Avg_list
    perc_perc_list = (1./nAvg)*perc_perc_list
    return vert_deg_list,net_Vt_list,Avg_list,RgR0_list,perc_perc_mean,perc_perc_std

#def MD_remap(array,mol_file,out_loc):
