import os

curr_path = '.'

for i in range(0,226):
    os.system('rm -r ./batch_'+str(i))

