from functions import *
import time

#Dimension of cubic lattice
lat_dim = 25
#Strength of interaction between sites.  Multiple of kT.  Negative Eint means lattice interactions lower energy.
Eint = -1.
#Number of MC steps to take when thermalizing the lattice
anneal_steps = 10000000
#Total Number of Kinetic Monte Carlo trajectories to perform per unique lattice
KMCtot_iter = 20000
#Total amount of time that each KMC trajectory should last (sec)
KMCtot_time = 10**-8
#Inverse temperature used for thermalizing lattice
beta_start = 8.0
#Inverse temperature to end annealing
beta_end = 8.0
#Anneal step size
anneal_step_size = 1.0
#Maximum coupling between two sites in a system (eV)
Hab = -.025
#Standard deviation in the coupling value, randomly assigned. Gaussian. (eV)
Habfluct = 0.000
#Conversion of eV to Joules
Habuse = Hab*1.6*(10**-19)
#Marcus reorganization energy for each site in the charge hopping process (eV)
lambdaC = 0.2
#Conversion of eV to Joules
lambdaCuse = 1.6*(10**-19)*lambdaC
#Space between lattice sites (nanometers).  Only use to scale x-axis of KMC distribution
lat_spacing = 1.0
#Standard deviation in the site energies, randomly assigned. Gaussian (eV)
Edisorder = 0.0
#Temperature to be used in the Marcus Hopping Rate (K)
Temp = 300.
#Type of lattice to be used. '0' sets up a perfectly crystalline lattice. '1' sets up a disordered lattice 
lat_type = '1'
#Number of unique lattices to generate, thermalize, and average results over
nAvg = 1
#Step size to be used when determining network properties as a function of coupling threshold.  It is best to keep this set to 1.  If you change it to an even number, you will get odd/even errors in the array sizes, which I need to fix.  Anything much larger than 0.002 gives uneven, choppy looking data.
net_step_size = 0.002

#Magnitude of the interaction along one of the three vectors orthogonal vectors, v1,v2,v3
v1Escale = 1.0
v2Escale = 0.0
v3Escale = 0.0
#Norm = math.sqrt(v1Escale**2+v2Escale**2+v3Escale**2)
Norm = 1.0
v1Escale = v1Escale/Norm
v2Escale = v2Escale/Norm
v3Escale = v3Escale/Norm
#plot_lattice_3D()

#Magnitude of the coupling along each of the three orthogonal vectors, v1,v2,v3
v1Hscale = 1.0
v2Hscale = 0.0
v3Hscale = 0.0

#Two routines: 1st routine performs lattice annealing, KMC, and coupling dist calculation. 2nd routine performs only lattice annealing and network analysis on those lattices.  Both average over Navg.  Simply comment one or the other out, or run both.

starttime = time.clock()
#Perform KMC Hopping and coupling distribution calc
cum_dist_array,coupling_list,coupdict = average_KMC(nAvg,anneal_steps,KMCtot_iter,KMCtot_time,lat_dim,lat_spacing,lat_type,beta_start,beta_end,v1Escale,v2Escale,v3Escale,Eint,Edisorder,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale,lambdaCuse,Temp,anneal_step_size)

#Make Plots
plot_KMC_results(cum_dist_array,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing)

endtime = time.clock()
print (endtime-starttime)/3600.

plot_coup_dist(coupdict,coupling_list,Hab,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing)

#Read off starting parameters

print "Eint*beta(start) = "+str(beta_start)+"\n"
print "Eint*beta(end) = "+str(beta_end)+"\n"
print "MIT = ("+str(v1Escale)+","+str(v2Escale)+","+str(v3Escale)+")\n"
print "MCT = ("+str(v1Hscale)+","+str(v2Hscale)+","+str(v3Hscale)+")\n"

#Perform network analysis

starttime = time.clock()
##uncomment the next two functions to enable percolation calcs
#vert_deg_list,net_Vt_list,Avg_list,RgR0_list,perc_perc_mean,perc_perc_std = average_netcalc(nAvg,lat_dim,anneal_steps,lat_spacing,lat_type,beta_start,beta_end,v1Escale,v2Escale,v3Escale,Eint,Edisorder,Habuse,Habfluct,v1Hscale,v2Hscale,v3Hscale,Hab,net_step_size,anneal_step_size)
endtime = time.clock()
#print "network analysis took " + str((endtime-starttime)/60.) + " minutes"

#Make Plots
#plot_Nnet_vs_Vt(net_Vt_list,Hab,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size)

#plot_VertDeg_vs_Vt(vert_deg_list,Hab,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size)

#plot_netAvg_vs_Vt(Avg_list,Hab,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size)
#UNCOMMENT THE BOTTOM FOR PERCOLATION RUN
#plot_RgR0(RgR0_list,perc_perc_mean,perc_perc_std,Hab,lat_dim,anneal_steps,v1Escale,v2Escale,v3Escale,v1Hscale,v2Hscale,v3Hscale,Eint,lat_spacing,net_step_size)

endtime = time.clock()

#print (endtime-starttime)/3600.
