import os
import sys
import numpy as np

work_path = '/home/nej544/Percolation_rewrite/Paper_Fig1/'
fold_path = '25latt_1D_EBeta5_wGB/'
fold_name = 'batch_'

os.chdir(work_path+fold_path)
folders = [i for i in os.listdir('.')]
array = np.zeros( (13,2,100) , dtype = float)
for name,s in zip(folders,range(len(folders))):
    os.chdir(name)
    txtfile = [k for k in os.listdir('.') if '.txt' in k][0]
    f = open(txtfile,'r')
    flines = f.readlines()
    for j,line in zip(range(len(flines)),flines):
        templine = line.split()
        array[j,0,s] = float(templine[0])
        array[j,1,s] = float(templine[1])
    f.close()
    os.chdir('..')

for i in range(len(array)):
    print str(np.mean(array[i,0]))+'\t'+str(round(np.mean(array[i,1]),3))+' +/- '+str(round(np.std(array[i,1]),3))
