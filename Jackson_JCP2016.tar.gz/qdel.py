import os

for i in range(577052,577352):
    os.system("qdel "+ str(i))
