import os
import sys
import numpy as np

work_path = '/home/nej544/Percolation_rewrite/Paper_Fig1/'
fold_path = '25latt_1D_EBeta0_KMC'
fold_name = 'batch_'

sample_num = 200

os.chdir(work_path+fold_path)
folders = [i for i in os.listdir('.')]
array = np.zeros( (sample_num) , dtype = float)
OParray = np.zeros( (sample_num) , dtype = float)
for name,s in zip(folders,range(len(folders))):
    os.chdir(name)
    txtfile = [k for k in os.listdir('.') if '.log' in k][0]
    f = open(txtfile,'r')
    flines = f.readlines()
    for line in flines:
        templine = line.split()
        if len(templine) > 0 and templine[0] == "mean":
            array[s] = float(templine[1])
    f.close()
    os.chdir('..')

#print OParray
print str(round(np.mean(array),3))+' +/- '+str(round(np.std(array),3))
