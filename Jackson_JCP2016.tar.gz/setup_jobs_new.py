import os
import sys

curr_mark = 200
num_avg = 25
work_path = '/home/nej544/Percolation_rewrite/Paper_Fig1/'
fold_path = '25latt_1D_EBeta8_KMC_wGB/'
fold_name = 'batch_'
temp_file_name = 'CTtemplate.submit'

template_file = open(work_path+temp_file_name,'r')
template = template_file.read()
mark1 = template.find('batch1')
mark2 = template.rfind('export')
template_first = template[:mark1]
template_last = template[mark2:]

#print template_first
#print '\n\n'
#print template_last

template_first = template_first.replace('workdir_holder/',work_path+fold_path)
template_last = template_last.replace('homedir_holder',work_path)

#print template_first
#print '\n\n'
#print template_last

for i in range(curr_mark+1,num_avg+curr_mark+1):
    os.chdir(work_path+fold_path)
    os.mkdir(fold_name+str(i))
    os.chdir(fold_name+str(i))
    submit = open('CT.submit','w')
    submit.write(template_first+'batch_'+str(i)+'\n')
    submit.write(template_last)
    submit.close()
    os.system('qsub CT.submit')

#print template_first
#print '\n\n\n'
#print template[mark2:]
